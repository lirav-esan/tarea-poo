import java.util.Scanner;

public class TDOCENTE extends TPERSONA {
//----------------------------------
//PROPIEDADES
//----------------------------------
private String Curso; // se asume 1 curs por profe pq me da flojera hacer un registro vectorial
private String Facultad;
private String CorreoIns;


//----------------------------------
//METODO CONSTRUCTOR
//----------------------------------
public TDOCENTE() {
    super();
}
//----------------------------------
//METODOS SET
//----------------------------------
public void Establecer_Curso(String curso) {
    this.Curso = curso;
}
public void Establecer_Facultad(String facultad) {
    this.Facultad = facultad;
}
public void Establecer_CorreoIns(String correoins) {
    this.CorreoIns = correoins;
}
//----------------------------------
//METODOS GET
//----------------------------------
public String Obtener_Curso() {
    return this.Curso;
}
public String Obtener_Facultad() {
    return this.Facultad;
}
public String Obtener_CorreoIns() {
    return this.CorreoIns;
}
//----------------------------------
//----------------------------------
public String Registro_Docente() {
Scanner OBJ = new Scanner(System.in);
TLib    LIB = new TLib();
String CAD,LINEA;
   LINEA = Registro_DatosGenerales();
   do {
      System.out.print(" - Curso            : ");
      CAD = OBJ.nextLine();
   } while(!LIB.ValidacionOK(CAD,"Curso",5,20,"ABCDEFGHIJKLMNOPQRSTUVWXYZ. abcdefghijklmnopqrstuvwxyz"));
   Establecer_Curso(CAD);
   do {
      System.out.print(" - Facultad            : ");
      CAD = OBJ.nextLine();
   } while(!LIB.ValidacionOK(CAD,"Facultad",5,20,"ABCDEFGHIJKLMNOPQRSTUVWXYZ. abcdefghijklmnopqrstuvwxyz"));
   Establecer_Facultad(CAD);
   do {
      System.out.print(" - CorreoIns            : ");
      CAD = OBJ.nextLine();
   } while(!LIB.ValidacionOK(CAD,"CorreoIns",5,20,"ABCDEFGHIJKLMNOPQRSTUVWXYZ. abcdefghijklmnopqrstuvwxyz@"));
   Establecer_CorreoIns(CAD);
   return LINEA +  " | " + 
          Curso + LIB.Replicate(' ',20 - Curso.length()) + " | " +
          Facultad + LIB.Replicate(' ',20 - Facultad.length()) + " | " + 
          CorreoIns + LIB.Replicate(' ',20 - CorreoIns.length());
}
//----------------------------------
} //class


