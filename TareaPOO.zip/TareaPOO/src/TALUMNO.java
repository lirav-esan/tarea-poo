import java.util.Scanner;

public class TALUMNO extends TPERSONA {
//----------------------------------
//PROPIEDADES
//----------------------------------
private String Codigo;
private String Facultad;
private String Especialidad;
private String Promocion;
//----------------------------------
//METODO CONSTRUCTOR
//----------------------------------
public TALUMNO() {
   super();
}
//----------------------------------
//METODOS SET
//----------------------------------
public void Establecer_Codigo(String codigo) {
    this.Codigo = codigo;
}
public void Establecer_Facultad(String facultad) {
    this.Facultad = facultad;
}
public void Establecer_Especialidad(String especialidad) {
    this.Especialidad = especialidad;
}
public void Establecer_Promocion(String promocion) {
    this.Promocion = promocion;
}
//----------------------------------
//METODOS GET
//----------------------------------
public String Obtener_Codigo() {
    return this.Codigo;
}
public String Obtener_Facultad() {
    return this.Facultad;
}
public String Obtener_Especialidad() {
    return this.Especialidad;
}
public String Obtener_Promocion() {
    return this.Promocion;
}
//----------------------------------
public String Registro_Alumnos() {
Scanner OBJ = new Scanner(System.in);
TLib    LIB = new TLib();
String CAD,LINEA;
   LINEA = Registro_DatosGenerales();

   do {
      System.out.print(" - Codigo           : ");
      CAD = OBJ.nextLine();
   } while(!LIB.ValidacionOK(CAD,"Codigo",5,20,"1234567890"));
   Establecer_Codigo(CAD);

   do {
      System.out.print(" - Facultad        : ");
      CAD = OBJ.nextLine();
   } while(!LIB.ValidacionOK(CAD,"Facultad",3,10,"ABCDEFGHIJKLMNOPQRSTUVWXYZ"));
   Establecer_Facultad(CAD);

   do {
      System.out.print(" - Especialidad        : ");
      CAD = OBJ.nextLine();
   } while(!LIB.ValidacionOK(CAD,"Especialidad",3,10,"ABCDEFGHIJKLMNOPQRSTUVWXYZ"));
   Establecer_Especialidad(CAD);

   do {
      System.out.print(" - Promocion        : ");
      CAD = OBJ.nextLine();
   } while(!LIB.ValidacionOK(CAD,"Promocion",3,10,"ABCDEFGHIJKLMNOPQRSTUVWXYZ"));
   Establecer_Promocion(CAD);

   return LINEA +  " | " + 
            Codigo + LIB.Replicate(' ',20 - Codigo.length()) + " | " + 
            Facultad + LIB.Replicate(' ',10 - Facultad.length()) + " | " + 
            Especialidad + LIB.Replicate(' ',10 - Especialidad.length()) + " | " + 
            Promocion + LIB.Replicate(' ',10 - Promocion.length());
}

//----------------------------------
//----------------------------------
} //class

