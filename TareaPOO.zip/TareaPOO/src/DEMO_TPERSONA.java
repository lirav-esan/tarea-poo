import java.io.IOException;  
import java.util.Scanner;

public class DEMO_TPERSONA {
//-----------------------------------------------
private static TLib LIB = new TLib();
private static String FILENAME = "DATOS.TXT";
//-----------------------------------------------
//-----------------------------------------------
public static void main(String[] args) throws IOException, InterruptedException {
int nn;
char TIPO,OPCION='?';
Scanner TECLADO = new Scanner(System.in);
TDOCENTE OBJ1 = new TDOCENTE();
TALUMNO          OBJ2 = new TALUMNO();
String CAD,LINEA="",DATA="";
   nn = 0;
   do {
      LIB.ClearScreen();
      System.out.println("=================================================");
      System.out.println("         HOSPITAL NACIONAL UNIVERSITARIO         ");
      System.out.println("          MODULO DE REGISTRO DE PERSONAL         ");
      System.out.println("=================================================");
      nn++;
      System.out.println("Registro Nro. " + nn);
      do {
         System.out.print(" - Tipo de Personal   : ");
         CAD = TECLADO.nextLine();
      } while(!LIB.ValidacionOK(CAD,"Tipo de Personal",1,1,"12"));
      TIPO = CAD.charAt(0);
      
      if(TIPO=='1') {
            LINEA = TIPO + " | " + OBJ1.Registro_Docente();
      }
      else {
            LINEA = TIPO + " | " + OBJ2.Registro_Alumnos();
      }
      DATA = DATA + LINEA + "\n";
      System.out.println("----------------------------------------------------");
      System.out.println();
      System.out.print("Desea Continuar? [S/N]: ");
      CAD = TECLADO.nextLine();
      OPCION = CAD.charAt(0);
   } while(OPCION!='N');
   if(LIB.ExistDataFile(FILENAME)) {
      LIB.AppendDataFile(DATA,FILENAME);
   }
   else {
      LIB.WriteDataFile(DATA,FILENAME);
   }
}
//-----------------------------------------------
}
